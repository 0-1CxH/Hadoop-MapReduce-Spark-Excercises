mvn clean package
hadoop jar target/qhu027_lab1-1.0-SNAPSHOT.jar input.txt output.txt
