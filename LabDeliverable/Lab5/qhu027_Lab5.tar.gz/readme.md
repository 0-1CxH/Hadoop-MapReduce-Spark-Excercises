# Lab 5

## Student information
* Full name: Qicheng Hu
* E-mail: qhu027@cs.ucr.edu
* UCR NetID: qhu027
* Student ID: X675102

## Answers

* (Q) What are these two arguments?

  The first required argument is "command", which defines the task by indicating which "case" branch to run; The second one is "inputfile", which gives the data source of this program.

